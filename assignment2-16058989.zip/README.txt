NOTE: for coordinates, they start at zero, instead of one. They range between 0-2 for X & Y values.
This was just more logical programming-wise.

Go to ---
http://localhost:8084/assignment2_server_16058989/TTT.jsp
http://localhost:8084/assignment2_server_16058989/ttt/*


JUnit test is in the tests folder of the Test project.