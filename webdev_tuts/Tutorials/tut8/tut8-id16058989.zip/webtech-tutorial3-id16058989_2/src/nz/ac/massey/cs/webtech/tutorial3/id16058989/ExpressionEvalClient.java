/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.massey.cs.webtech.tutorial3.id16058989;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;



/**
 *
 * @author Octet (Dylan Tonks)
 * Student ID 16058989
 */
public class ExpressionEvalClient {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            System.out.println("Enter expression to evaluate, type exit to exit");
            String line = br.readLine();
            if ("exit".equals(line)) System.exit(0);
            analyse(line);
        }   
    }
    
    private static void analyse(String expression) throws Exception {
        HttpClient client = new DefaultHttpClient();
        
        //Initialize a new HttpPost object. Excuse the port, 8084
        HttpPost post = new HttpPost("http://localhost:8084/webtech-tutorial2-id16058989/CalculatorService");
        
        try {
            
            //Add the 'expression' parameter to the POST request.
            List<NameValuePair> params = new ArrayList<NameValuePair>(1);
            params.add(new BasicNameValuePair("expression", expression));
            
            //Add the params to the URL
            post.setEntity(new UrlEncodedFormEntity(params));
            
            //Send the POST request
            HttpResponse response = client.execute(post);
            
            //Retrieve the response through a buffer reader
            BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent())
            );
            
            char[] json = new char[30]; //I know this'll error out above x characters
            rd.read(json);
            
            
            //Convert the result to a JSON object, get the 'result'
            JSONObject obj = new JSONObject(new String(json));
            String result = obj.getString("result");
            
            //Output the result sent as JSON
            System.out.println(result);
                
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        
    }

}
